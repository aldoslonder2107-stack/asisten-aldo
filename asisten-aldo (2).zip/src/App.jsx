import React from 'react';
import ChatAssistant from './ChatAssistant';

function App() {
  return (
    <div>
      <h1>Asisten Aldo Aktif</h1>
      <ChatAssistant />
    </div>
  );
}

export default App;